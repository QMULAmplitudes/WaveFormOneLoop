clear; %close all;
% parameters that can be tuned
max_zv=15; % no difference between 15 and 20
max_zb=50; % small differences between 50 and 100
omega=[-20:0.5:-1,1:0.5:20]; % avoid the singular point at omega=0
data_id=4;

zv=cumsum(0:max_zv); % use non-uniform grid to speed up
zb=-max_zb:max_zb; % use uniform grid in zb-direction
[ZV,ZB] = meshgrid(zv,zb); % the 2D zv-zb grid
hann_window=cos(pi*zb/max_zb)*0.5+0.5; % crucial
amplitude_frequency=zeros(1,length(omega)); % frequency-domain amplitude

% loop over the frequency points
for n_omega=1:length(omega)
    disp('omega=');
    disp(omega(n_omega));
    % calcualte the integrand in the 2D grid
    tic
    if data_id==1
        F=waveformIntgrand1(ZV,ZB,omega(n_omega));
    elseif data_id==2
        F=waveformIntgrand2(ZV,ZB,omega(n_omega));
    elseif data_id==3
        F=waveformIntgrand1MM(ZV,ZB,omega(n_omega));
    else
        F=waveformIntgrand2MM(ZV,ZB,omega(n_omega));
    end
    toc
    temp=zeros(1,length(zb));
    for n_zb=1:length(zb)
        temp(n_zb)=trapz(zv,F(n_zb,:)); % integration over zv
    end
    % integration over zb
    amplitude_frequency(n_omega)=trapz(zb,temp.*hann_window);
end

amplitude_frequency=amplitude_frequency.*omega.^2;

if data_id==3
    omega=omega(abs(amplitude_frequency)<40);
    amplitude_frequency=amplitude_frequency(abs(amplitude_frequency)<40);
else
    omega=omega(abs(amplitude_frequency)<3);
    amplitude_frequency=amplitude_frequency(abs(amplitude_frequency)<3);
end

% Define the Fourier transform parameters
f=omega/2/pi;
df=f(2)-f(1);
f_max=max(abs(f));
dt=1/f_max/2;
t_max=1/df/2;
t=(-t_max:dt:t_max);

% Transform from frequency domain to time domain
amplitude_time=zeros(1,length(t));
hann_window2=cos(pi*f/f_max)*0.5+0.5; % crucial
for n=1:length(t)
    amplitude_time(n)=trapz(f,hann_window2.*exp(-1i*omega*t(n)).*amplitude_frequency);
end

figure;
subplot(1,2,1);
plot(omega,real(amplitude_frequency),'s-','linewidth',3);hold on;
plot(omega,imag(amplitude_frequency),'o-','linewidth',3);
xlabel('\omega','fontsize',15);
ylabel('Frequency-domain amplitude','fontsize',15);
legend('real','imag');
axis tight;
set(gca,'fontsize',15);

subplot(1,2,2);
plot(t,real(amplitude_time),'s-','linewidth',3);hold on;
plot(t,imag(amplitude_time),'o-','linewidth',3);hold on;
xlabel('Time','fontsize',15);
ylabel('Time-domain amplitude','fontsize',15);
legend('real','imag');
axis tight;
set(gca,'fontsize',15);

if data_id==1
    fid_frequency=fopen('amplitude_frequency_1.txt','w');
    fid_time=fopen('amplitude_time_1.txt','w');
elseif data_id==2
    fid_frequency=fopen('amplitude_frequency_2.txt','w');
    fid_time=fopen('amplitude_time_2.txt','w');
elseif data_id==3
    fid_frequency=fopen('amplitude_frequency_1MM.txt','w');
    fid_time=fopen('amplitude_time_1MM.txt','w');
else
    fid_frequency=fopen('amplitude_frequency_2MM.txt','w');
    fid_time=fopen('amplitude_time_2MM.txt','w');
end
for n_omega=1:length(omega)
    fprintf(fid_frequency,'%15.6f%15.6f%15.6f\n',omega(n_omega),...
        real(amplitude_frequency(n_omega)),imag(amplitude_frequency(n_omega)));
end
for n_time=1:length(t)
    fprintf(fid_time,'%15.6f%15.6f%15.6f\n',t(n_time),...
        real(amplitude_time(n_time)),imag(amplitude_time(n_time)));
end
fclose(fid_frequency);
fclose(fid_time);



