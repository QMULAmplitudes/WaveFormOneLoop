clear; close all;
data=load('amplitude_frequency_1.txt');
omega=data(:,1);
amplitude_frequency=data(:,2)+1i*data(:,3);

%omega=omega([1:6,9:16,18:53,55:62,66:71].');
%amplitude_frequency=amplitude_frequency([1:6,9:16,18:53,55:62,66:71].');
omega_new = [-20:0.1:-0.1,0.1:0.1:20].';
amplitude_frequency_new = spline(omega,amplitude_frequency,omega_new);

% Define the Fourier transform parameters
f=omega_new/2/pi;
f_max=max(abs(f));
t=-4:0.02:4;

% Transform from frequency domain to time domain
amplitude_time=zeros(1,length(t));
hann_window2=cos(pi*f/f_max)*0.5+0.5; % crucial
for n=1:length(t)
    amplitude_time(n)=trapz(f,hann_window2.*exp(-1i*omega_new*t(n)).*amplitude_frequency_new);
end

figure;
subplot(1,2,1);
plot(omega_new,real(amplitude_frequency_new),'-','linewidth',3);hold on;
plot(omega_new,imag(amplitude_frequency_new),'-','linewidth',3);
xlabel('\omega','fontsize',15);
ylabel('Frequency-domain amplitude','fontsize',15);
legend('real','imag');
axis tight;
set(gca,'fontsize',15);

subplot(1,2,2);
plot(t,real(amplitude_time),'-','linewidth',3);hold on;
plot(t,imag(amplitude_time),'-','linewidth',3);hold on;
xlabel('Time','fontsize',15);
ylabel('Time-domain amplitude','fontsize',15);
legend('real','imag');
axis tight;
set(gca,'fontsize',15);

fid_frequency=fopen('amplitude_frequency_1spline.txt','w');
fid_time=fopen('amplitude_time_1spline.txt','w');
for n_omega=1:length(omega_new)
    fprintf(fid_frequency,'%15.6f%15.6f%15.6f\n',omega_new(n_omega),...
        real(amplitude_frequency_new(n_omega)),imag(amplitude_frequency_new(n_omega)));
end
for n_time=1:length(t)
    fprintf(fid_time,'%15.6f%15.6f%15.6f\n',t(n_time),...
        real(amplitude_time(n_time)),imag(amplitude_time(n_time)));
end
fclose(fid_frequency);
fclose(fid_time);



